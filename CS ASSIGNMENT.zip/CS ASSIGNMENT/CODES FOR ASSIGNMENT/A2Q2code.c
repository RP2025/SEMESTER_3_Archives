#include<stdio.h> 
#define PI 3.1415926
int main() 
{ 
    double r, h, v; 
    printf("Enter radius and height of cylinder: "); 
    scanf("%lf %lf", &r, &h);   
  
    v = PI * r * r * h; 
    printf("Volume of cylinder = %lf", v); 
     
    return 0; 
} 