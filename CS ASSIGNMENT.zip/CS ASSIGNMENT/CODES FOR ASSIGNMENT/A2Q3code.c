#include<stdio.h> 
int main() 
{ 
    double Basic_salary , DA , HRA , TA , other , PF, IT ,Net;
    printf("Enter the basic salary : "); 
    scanf("%lf", &Basic_salary);   
    DA = 0.12*Basic_salary;
    PF = 0.14 * Basic_salary;
    IT = 0.15 * Basic_salary;
    HRA = 4000;
    TA = 2000;
    other = 1000;
    Net = Basic_salary + DA + HRA + TA + other - PF-IT;
    printf("Net Salary is : %lf", Net); 
     
    return 0; 
} 