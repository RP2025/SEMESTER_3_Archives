#include<stdio.h>
int main() 
   {
	double w1, c1, w2, c2, result;
    printf("Weight of  Item 1: ");
	scanf("%lf", &w1);
	printf("No. of item 1: ");
	scanf("%lf", &c1);
	printf("Weight of Item 2: ");
	scanf("%lf", &w2); 
	printf("No. of item 2: ");
	scanf("%lf", &c2);
	result = ((w1 * c1) + (w2 * c2)) / (c1 + c2);
	printf("Average Value = %f\n", result);
	return 0;
}
