#include<stdio.h>
int main() 
   {
    int dis;
	double fuel, avg_consumption;
    printf("Enter distance travelled in km :");
	scanf("%ld", &dis);
	printf("Enter fuel spent in liters :");
	scanf("%lf", &fuel);
	avg_consumption = dis/fuel;
	printf("Average consumption in km/Lt = %f\n", avg_consumption);
	return 0;
}
