#include<stdio.h>
#include<math.h>
int main() 
   {
    int x1,y1,x2,y2;
	double distance;
    printf("Enter cordinates \n ");
    printf("X1 :");
	scanf("%ld", &x1);
    printf("Y1 :");
	scanf("%ld", &y1);
    printf("X2:");
	scanf("%ld", &x2);
    printf("Y2 :");
	scanf("%ld", &y2);
    distance= sqrt(pow(x2-x1,2) + pow(y2-y1,2));
    printf("the distance between given coordinates is : %lf \n", distance);
	return 0;
}
