#include <stdio.h>
void main()
{
 int n , x;
 printf("Enter x and n");
 scanf("%d%d",&x,&n);

 //first series
 int sum1=0;
 for(int i=1;i<=n;i++){
     sum1=sum1+i;
 }
 printf("sum of first series is %d \n" , sum1);
 
 //Second Series
 int sum2=1;
 int z=1;
 for(int i=1;i<n;i++){
     for(int j = 1; j<i+1 ;j++){
         z*=x;
    }
    sum2=sum2+z;
    z =1;
}
printf("sum of second series is %d \n" , sum2);

// third series
 float sum3=1;
 float z2=1;
 for(float i=1;i<n;i++){
     for(float j = 1; j<i+1 ;j++){
         z2*=x/j;
     }
    sum3=sum3+z2;
    z2 =1;
}
printf("sum of third series is %f \n" , sum3);

// fourth series
int sum4 =0;
for(int i =1;i<=n;i++){
    if(i%2==0){
        sum4=sum4-i;
    }
    else {
        sum4=sum4+i;
    }
  
}
printf("sum of forth series is %d \n" , sum4);

//fifth series
int sum5=0;
for(int i=1;i<=n;i++){
     sum5=sum5+(2*i);
 }
 printf("sum of fifth series is %d \n" , sum5);

}