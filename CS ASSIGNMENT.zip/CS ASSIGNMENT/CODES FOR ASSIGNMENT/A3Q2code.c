#include<stdio.h> 
int main() 
{ 
    printf("enter the character:");
    char ch;
    scanf("%c", &ch);
    if(ch=='a'|| ch == 'e'|| ch == 'i'|| ch == 'o'|| ch == 'u'|| ch == 'A'|| ch == 'E'|| ch == 'O'|| ch == 'I'|| ch == 'U')
    {
        printf("entered character is Vowel");
    }
    else
    {
        printf("entered character is Consonent");
    }
    return 0;
} 