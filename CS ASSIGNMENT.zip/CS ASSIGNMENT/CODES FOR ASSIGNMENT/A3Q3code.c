#include<stdio.h> 
int main() 
{ 
   printf("enter number::");
    int a;
    int b=0;
    scanf("%d", &a);
    while(a){
        b+=a%10;
        a/=10;

    }
    printf("sum of digits is %d" , b);
} 