#include<stdio.h> 
int main() 
{ 
    printf("enter year:");
    int a;
    scanf("%d",&a);
    
    if (a%4==0)
    {
        if(a%400==0 || a%100!= 0)
        {
            printf("It is a leap year");
        }
    }
    else 
        {  
            printf("It is not a leap year");  
        }
    return 0;
}