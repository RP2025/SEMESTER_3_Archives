#include<stdio.h> 
int main() 
{ 
    printf("enter number:");
    int num;
    int num2=0;
    scanf("%d",&num);
    while(num!= 0)
    {
        num2 = (num2 * 10) + (num % 10);
        num /= 10;
    }
    while(num2 != 0)
    {
        switch(num2 % 10)
        {
            case 0: 
                printf("Zero ");
                break;
            case 1: 
                printf("One ");
                break;
            case 2: 
                printf("Two ");
                break;
            case 3: 
                printf("Three ");
                break;
            case 4: 
                printf("Four ");
                break;
            case 5: 
                printf("Five ");
                break;
            case 6: 
                printf("Six ");
                break;
            case 7: 
                printf("Seven ");
                break;
            case 8: 
                printf("Eight ");
                break;
            case 9: 
                printf("Nine ");
                break;
        }
        
        num2/=10;
    }

    return 0;
}
