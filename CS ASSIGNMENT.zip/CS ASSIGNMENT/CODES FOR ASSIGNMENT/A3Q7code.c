#include<stdio.h>
 
void main()
{
    int x,y,z;
    printf("Enter x and y");
    scanf("%d%d",&x,&y);
    z =1;
    for(int i=0;i<y;i++){
        z=z*x;
    }
    printf("the value of required expression is %d" , z);
}