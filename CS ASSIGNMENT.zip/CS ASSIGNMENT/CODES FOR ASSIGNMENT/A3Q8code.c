#include <stdio.h>  
int main()  
{  
    int n1, n2, GCD;  
    printf ( "Enter any two numbers: \n ");  
    scanf ( "%d %d", &n1, &n2);   
      
    // use for loop  
    for( int i = 1; i <= n1 && i <= n2; ++i)  
    {  
        if (n1 % i ==0 && n2 % i == 0)  
            GCD = i; 
    }  
    // print the GCD of two numbers  
    printf ("GCD of two numbers is %d",  GCD);  
    return 0;  
}  