#include <stdio.h>
void main()
{
   int sum=0;
   for(int i= 21 ;i<30;i++)
   {
     if(i%2==0&&i%3==0)
     {
      sum+=i;
     }
   }
   printf("Sum of numbers between 20 and 30, divisible by 2 and 3 is %d: \n" , sum);
}
