#include <stdio.h>  
  
int main()  
{  
    int n;  
    printf("Enter the number of rows");  
    scanf("%d",&n);  
    //Pattern a
    int m =1;
    for(int i=n;i>=1;i--)  
    {  
        for(int j=1;j<=i-1;j++)  
        {  
          printf(" ");  
        }  
        for(int k=1;k<=m;k++)  
        {  
            printf("*");  
        }  
        printf("\n");  
        m++;  
    }


    //Pattern b
    int k =1;
    for(int i=1;i<=n;i++)  
    {   for(int j=1;j<=i;j++)  
        {  
            printf("%d ",k);
            k=k+1;  
        }  
        printf("\n");  
    }  
    //Pattern c
    int l =1;
    for(int i=1;i<=n;i++)
    {
  	    for(int j=i;j<n;j++)
        {
  	        printf(" ");
        }
        for(k=1;k<=2*i-1;k++)
        {
   	        printf("%d",l);
        l++;
        }
        
        printf("\n");
    }
// Pattern d
m =1;
char ch ='A';
    for(int i=n;i>=1;i--)  
    {  
        for(int j=1;j<=i-1;j++)  
        {  
          printf(" ");  
        }  
        for(int k=1;k<=m;k++)  
        {  
            printf("%c",ch); 
            ch++; 
        }  
        printf("\n");  
        m++;  
    }

   
    return 0;  
}  