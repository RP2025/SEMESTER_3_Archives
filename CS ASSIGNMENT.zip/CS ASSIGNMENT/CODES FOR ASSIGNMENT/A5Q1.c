#include<stdio.h>
int main()
{
        int n;
        printf("Enter size of array \n");
        scanf("%d",&n);
        int ar[n];
        printf("Enter the nmbers you want to store in array \n");
        for(int i =0;i<n;i++)
        {       int num;
                scanf("%d",&num);
                ar[i]=num;
        }
        int max , min;
        max = ar[0];
        min = ar[0];
        for(int i =0;i<n;i++)
        {
                if(max<ar[i])
                {
                        max = ar[i];
                }

                if(min>ar[i])
                {
                        min = ar[i];
                }
        }
        printf("Maxinum element in array is %d \n" , max);
        printf("Minimum element in array is %d \n" , min);

}
