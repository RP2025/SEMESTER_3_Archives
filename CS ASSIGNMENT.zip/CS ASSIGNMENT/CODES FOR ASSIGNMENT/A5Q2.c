#include<stdio.h>
int main()
{
        int n;
        printf("Enter size of array \n");
        scanf("%d",&n);
        int ar[n];
        printf("Enter the numbers you want to store in array \n");
        for(int i =0;i<n;i++)
        {       int num;
                scanf("%d",&num);
                ar[i]=num;
        }
        int ar_copy[n];
        for(int i =0;i<n;i++)
        {
                int copy = ar[i];
                ar_copy[i] = copy;
        }
        return 0;
}
