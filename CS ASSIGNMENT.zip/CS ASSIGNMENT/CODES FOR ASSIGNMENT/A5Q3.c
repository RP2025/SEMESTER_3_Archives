
#include<stdio.h>
int main()
{
        int n;
        printf("Enter Size of Array");
        scanf("%d",&n);
        printf("Enter elements of Array");
        int ar[n];
        for(int i = 0;i<n;i++)
        {
                scanf("%d", &ar[i]);
        }
        for(int i =0;i<n;i++)
        {
                for(int j =0;j<n-1;j++)
                {
                        if (ar[j] > ar[j + 1])
                        {
                                int swap = ar[j];
                                ar[j]=ar[j+1];
                                ar[j+1] = swap;
                        }
                }
        }
        printf("Sorted array is : \n");
        for(int i = 0;i<n;i++)
        {
                printf("%d \n", ar[i]);
        }
        return 0;
}
