#include<stdio.h> 
int main() 
{  
    printf("enter size of array");
    int n;
    scanf("%d", &n);
    printf("enter the elements in array");
    int ar[n];
    for(int i=0;i<n;i++)
    {   int ac;
        scanf("%d", &ac);
        ar[i]=ac;

    }  
    for(int i =0;i<n;i++)
        {
                for(int j =0;j<n-1;j++)
                {
                        if (ar[j] > ar[j + 1])
                        {
                                int swap = ar[j];
                                ar[j]=ar[j+1];
                                ar[j+1] = swap;
                        }
                }
        }

    int i , j , t,duplicate_element =0; 
    for(i =0;i<n;)
    {   int count =0;
        for(j=i+1 ; j<n;j++){
            if(ar[i]==ar[j]){
                count++;
                t =j;

            }
        }
        if(count>0){
          duplicate_element++; 
          i=t;
        }
        else {
            i++;
        }
        
    } 
    printf("The number of duplicate element in array is :: %d " , duplicate_element);
    return 0;
} 