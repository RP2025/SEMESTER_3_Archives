#include<stdio.h> 
int main() 
{  
    printf("enter size of array");
    int n;
    scanf("%d", &n);
    printf("enter the elements in array");
    int ar[n];
    for(int i=0;i<n;i++)
    {   int ac;
        scanf("%d", &ac);
        ar[i]=ac;

    }   
    int max_count = 0;
    int max =0;
    int i=0;
    for(int i =0;i<n;i++){
        int count =0;
        for(int j=i+1 ; j<n;j++){
            if(ar[i]==ar[j]){
                count++;
            }
        }
        if(max_count<count){
          max = ar[i];  
        }
        
    } 
    printf("The number that is repeated maximum number of times is :: %d " , max);
    return 0;
} 