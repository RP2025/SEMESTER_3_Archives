#include<stdio.h>
int main()
{
        printf("Enter number of rows and columns in matrix \n");
        int r,c;
        scanf("%d%d", &r ,&c);
        int ar1[r][c] , ar2[r][c] , sum[r][c];
        printf("Enter elements of matrix 1 \n");
        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                        scanf("%d",&ar1[i][j]);
                }
        }

        printf("Enter elements of matrix 2 \n");
        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                        scanf("%d",&ar2[i][j]);
                }
        }

        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                        sum[i][j]=ar1[i][j]+ar2[i][j];
                }
        }
        printf("Sum of two matrix is \n");
        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                        printf("%d " , sum[i][j]);
                }
                printf("\n");
        }

        return 0;
}

