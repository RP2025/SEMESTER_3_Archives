#include<stdio.h>
int main()
{
        printf("Enter number of rows and columns in matrix \n");
        int r,c;
        scanf("%d%d", &r ,&c);
        int ar1[r][c] , ar2[c][r];
        printf("Enter elements of matrix  \n");
        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                        scanf("%d",&ar1[i][j]);
                }
        }

        for(int i=0;i<r;i++)
        {
                for(int j =0;j<c;j++)
                {
                       ar2[j][i]=ar1[i][j];
                }
        }
        printf("transpose of given matrix will be \n");

        for(int i=0;i<c;i++)
        {
                for(int j =0;j<r;j++)
                {
                        printf("%d " , ar2[i][j]);
                }
                printf("\n");
        }


        return 0;
}
