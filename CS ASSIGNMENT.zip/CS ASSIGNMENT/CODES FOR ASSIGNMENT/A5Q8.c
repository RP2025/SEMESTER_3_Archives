#include<stdio.h> 
int main() 
{  
    printf("enter number of row in array");
    int r;
    scanf("%d", &r);
    printf("enter the elements in array");
    int ar[r][r];
    for(int i=0;i<r;i++){
        for(int j =0;j<r;j++){
            scanf("%d", &ar[i][j]);

        }

    }  
    //Part A
    // for symetrical array , r=r
    int a = 1;
    for(int i=0;i<r;i++){
        for(int j =0;j<r;j++){
            if(ar[i][j]!=ar[j][i]){
                a = 0;
            }
        }
    }
    if(a==0){
        printf("array is Not symm \n");
    }
    else{
        printf("array is symm \n");
    }

  // Part B
  int b = 1;
  for(int i=0;i<r;i++){
        for(int j =i+1;j<r;j++){
            if(ar[i][j]!=0){
                b =0;
            }
        }
   }
   if(b==0){
        printf("array is not Lower triangular \n");
    }
    else{
        printf("array is Lower triangular \n");
    }

    //Part C
    int c =1;
    for(int i=0;i<r;i++){
        if(ar[i][i]!=0){
            c = 0;
        }
    }

    if(c==0){
        printf("array is not Diagonal \n");
    }
    else{
        printf("array is Diagonal \n");
    }

    int sum1=0;
    for(int i=0;i<r;i++){
        sum1+=ar[i][i];
    }

    int sum2 =0;
     for(int i=0;i<r;i++){
        sum2+=ar[i][r-i-1];
     }
    printf("Sum of diagonal 1 is %d \n" , sum1);
    printf("Sum of diagonal 2 is %d \n" , sum2);


return 0;
}