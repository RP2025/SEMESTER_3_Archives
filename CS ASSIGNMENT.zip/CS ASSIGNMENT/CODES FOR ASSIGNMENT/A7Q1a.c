#include<stdio.h>
int power(int x , int n)
{   int powerno = 1;
    for(int i = 0 ; i < n ; i++)
    {
        powerno = powerno * x;
    }
    return powerno;
}
int main()
{
    int x,n;
    scanf("%d%d" , &x,&n);
    int powno = power(x , n);
    printf("%d" , powno);
}