#include<stdio.h>
int sumofarray(int len)
{   int arr[len];
    printf("Enter the elements of array");
    for(int i = 0; i< len ; i++)
    {
        scanf("%d",&arr[i]);
    }
    int n;
    printf("Enter the number of element of which you want sum");
    scanf("%d" , &n);

    int sum = 0;
    for(int i = 0 ; i< n ; i++)
    {
        sum = sum + arr[i];
    }
    return sum;
}

int main()
{
    printf("Enter the size of array");
    int size;
    scanf("%d" , &size);
    int sum_required = sumofarray(size);
    printf("The sum of first N elements of array is %d " , sum_required);
    return 0;
}