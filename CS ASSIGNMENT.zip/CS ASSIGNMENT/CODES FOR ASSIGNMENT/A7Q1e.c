#include<stdio.h>
#include<string.h>
int bs(char string[])
{
    int len = strlen(string);
    int j;
    for(int i = 0 ; i<len ; i++)
    {
        if(string[i] == ' ')
        {
          for(int j = i; j< len ; j++)
          {
            string[j] = string[j+1];
          }  
        }
    }
    printf("%s" , string);
    return 0;
}

int main()
{
    char str[100];
    fgets(str, 100, stdin);
    bs(str);
}
