#include<stdio.h>
#include<string.h>
char reverse(char s[])
{
    int length = strlen(s);
    char s_rev[100];
    int j = length-1;
    int i = 0;
    while(s[i]!='\0')
    {
        s_rev[j] = s[i];
        j--;
        i++;
    }
    s_rev[length] = '\0';
    printf("%s" , s_rev);
}
int main()
{
    char stri[100];
    fgets(stri , 100 , stdin);
    reverse(stri);
    return 0;
}