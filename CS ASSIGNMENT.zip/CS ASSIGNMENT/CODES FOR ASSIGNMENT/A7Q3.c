#include<stdio.h>
#include<string.h>
int substr(char s1[], char s2[])
{
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    int i = 0;
    int j = 0;
    while(s1[i]!= '\0')
    {   
        if(s1[i] == s2[j])
        {
            j++;
        }
        i++;
   }
   if( j == len2)
   {
    printf("EQUAL");
   }
   else{
    printf("NO");
   }
}

int main()
{
    char s1[100];
    char s2[100];
    fgets(s1,100,stdin);
    fgets(s2,100,stdin);
    substr(s1,s2);
}