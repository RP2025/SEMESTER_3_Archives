#include<stdio.h>
int largestNo(int r , int c)
{   int arr[r][c];
    printf("Enter the elements of array");
    for(int i = 0 ; i< r;i++){
        for(int j = 0; j< c ; j++){
            scanf("%d" , &arr[i][j]);
        }
    }
    int maxno = arr[0][0];
    for(int i = 0 ; i< r;i++)
    {
        for(int j = 0; j< c ; j++)
        {
            if(arr[i][j]>maxno)
            {
                maxno = arr[i][j];
            }
        }
    }
    return maxno;
}

int main()
{
    int r ,c;
printf("Enter no of rows and coloums you want");
scanf("%d%d" , &r,&c);
int max_no = largestNo(r ,c);
printf("MAX no is %d" , max_no);
return 0;
}