#include<stdio.h>
int largestNo(int r , int c)
{   int arr[r][c];
    printf("Enter the elements of array");
    for(int i = 0 ; i< r;i++){
        for(int j = 0; j< c ; j++){
            scanf("%d" , &arr[i][j]);
        }
    }
    int maxrow[r];
    int maxcol[c];
    for(int i = 0 ; i< r;i++)
    {   int maxno = arr[i][0];
        for(int j = 0; j< c ; j++)
        {
            if(arr[i][j]>maxno)
            {
                maxno = arr[i][j];
            }
        }
        maxrow[i] = maxno;
    }
    
    for(int j = 0 ;j<c;j++)
    {   int maxno = arr[0][j];
        for(int i = 0; i< c ; i++)
        {   
            if(arr[i][j]>maxno)
            {
                maxno = arr[i][j];
                
            }

        }
        maxcol[j] = maxno;
        
    }

    for(int i = 0 ; i< r;i++)
    {
        printf("%d " , maxrow[i]);
    }
    printf("\n");
    for(int i = 0 ; i< c;i++)
    {
        printf("%d " , maxcol[i]);
    }
    printf("\n");
}



int main()
{
    int r ,c;
printf("Enter no of rows and coloums you want");
scanf("%d%d" , &r,&c);
largestNo(r ,c);
return 0;
}