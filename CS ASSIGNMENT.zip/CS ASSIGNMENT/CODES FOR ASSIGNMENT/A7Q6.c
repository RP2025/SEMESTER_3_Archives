#include <stdio.h>

int reverseIntger(int n) {

int reverse = 0;
int remainder;

  while (n != 0) {
    remainder = n % 10;
    reverse = reverse * 10 + remainder;
    n /= 10;
  }
  return reverse;
}

int main()
{
    int n;
    scanf("%d" , &n);
    int revno = reverseIntger(n);
    printf("The reversed number %d " , revno);
}