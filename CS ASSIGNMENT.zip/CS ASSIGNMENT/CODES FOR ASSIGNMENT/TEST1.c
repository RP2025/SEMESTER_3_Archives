#include <stdio.h>
int main ()
 {
 int a = 4;
  int x = ++a + ++a;
 printf ("alue of x = %d\n", x);
 printf ("Value of a = %d\n", a);

 return 0;
 }
