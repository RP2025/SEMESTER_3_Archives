#include<stdio.h>  
int main(){  
   //t2(123456789);
   //t3(123,345,3526);

    char ab;
    int z = sizeof(ab);
    printf("%d \n\n\n\n",z);
for(int i =1;i<6;i++){
   for(int j =5;j>i;j--)
   {
      printf(" ");
   } char c = 'A'; 
      for(int k =1;k<=(2*i-1);k++){
      
      printf("%c",c);
      c++;
   }
   printf("\n");
 }

for(int i =5;i>0;i--)
{
   for(int j =0;j<i;j++){
      printf("t");
   }
   printf("\n");
}
return 0;
}
int t4(){

for(int i =1;i<=5;i++)
{
   for(int j =1;j<=i;j++){
      if(j%2==1){
         printf("1");

      }
      else{
         printf("0");
      }
   }
   printf("\n");
}
 for(int i =1;i<6;i++){
   for(int j =5;j>i;j--)
   {
      printf(" ");
   }
   for(int k =1;k<=(2*i-1);k++){
      printf("%d",k);
   }
   printf("\n");
 } 

   for(int i =1 ;i<=4;i++){
      for(int j = 1; j<=i;j++)
      {printf("x");}
      printf("\n");
   }
   for(int i =1 ;i<=4;i++){
         for(int j =1;j<i;j++){
            printf(" ");
         }

         for(int k =1;k<=i;k++){
         printf("y");
         
      }
      printf("\n");
   }
   int n=4;

for(int i=n;i>0;i--)
    {
	    for(int j=n-i;j>0;j--)
        {
            printf(" ");
        }
        
		for(int j=0;j<i;j++)
        {
            printf("R");
        }
        printf("\n");
    } 


    printf("dgdfGHJKLigdbk \n");
    for(int i=1;i<4;i++){
      for(int j = 3;j>i;j--){
       printf(" ");
      }
      for(int k =1;k<=i;k++)
      {
         printf("W");
      }
      printf("\n");
    }
   char ch = 'A';
   n=4;
     for(int i=1;i<(n+1);i++){
      for(int j = n;j>i;j--){
       printf(" ");
      }
      for(int k =1;k<=i;k++)
      {
         printf("%c" , ch);
         ch++;
      }
      printf("\n");
    }
   //asc('B');
   return 0;
}
void asc(char c){
   if(c>=65 && c<=90){
      printf("%c",c+1);
   }
}
int t3(int x,int y,int z){
   (x>y&&x>z)?(printf("x")):(printf(""));
   (y>x&&y>z)?(printf("y")):(printf(""));
   (z>y&&z>x)?(printf("z")):(printf(""));
   
}
int t2(int n)
{  int r =0;
int s=0;

   while(n>0){
      r=r*10;
      r=r+n%10;
      
      s=s+n%10;
      n=n/10;
   }
printf("%d \n %d" , r , s);
   return 0;
}
//int q1()
//{int a[10],n,i;    
 
//printf("Enter the number to convert: ");    
//scanf("%d",&n);    
//for(i=0;n>0;i++)    
//{    //
//a[i]=n%2;    
//n=n/2;    
//}    
//printf("\nBinary of Given Number is=");    
//for(i=i-1;i>=0;i--)    
//{    
//printf("%d",a[i]);    
//}    
//return 0; 
//}

