#include<stdio.h> 
int main() 
{  
    printf("enter size of array and range of number");
    int n ,k;
    scanf("%d%d", &n , &k);
    printf("enter the elements in array");
    int ar[n];
    for(int i = 0 ; i<n;i++)
    {
        scanf("&d", &ar[i]);

    }   
    int max_count = 0;
    int max =0;
    for(int i = 0;i<n;i++){
        int count =0;
        for(int j=i+1 ; j<n;j++){
            if(ar[i]==ar[j]){
                count++;
            }
        }
        if(max_count<count){
          max = ar[i];  
        }
    } 
    return 0;
} 