def hellol(n: int) ->int:
    print("Hello")
    print(n)
    return n

def hell2() ->int:
    print("GET LOST")

hellol(5)
hell2()