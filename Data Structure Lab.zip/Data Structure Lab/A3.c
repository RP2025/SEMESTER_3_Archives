#include <stdio.h>
#include <stdlib.h>
struct stack
{
  int top;    // peeks top element of the stack
  int *data;  // array (variable size array)
  int length; // user defined length
};
void init(struct stack *s1)
{
  s1->top = -1;
}
struct stack createIntegerStack(int stackSize)
{
  if (stackSize <= 0)
  {
    struct stack s3;
    init(&s3);
    s3.length = stackSize;
    return s3;
  }
  struct stack s2;
  init(&s2);
  s2.data = (int *)malloc(stackSize * sizeof(int));
  s2.length = stackSize;
  return s2;
}
int pushIntegerStack(struct stack *s1, int d)
{
  if ((s1->top == (s1->length) - 1) || (s1->length <= 0))
  {
    return 0;
  }
  s1->data[++(s1->top)] = d;
  return 1;
}
int popIntegerStack(struct stack *s, int *dp)
{
  if ((s->top == -1) || (s->length <= 0))
  {
    return 0;
  }
  *dp = s->data[(s->top)--];
  return 1;
}
int freeIntegerStack(struct stack *s)
{
  if ((s->top == -1) || (s->length <= 0))
  {
    return 0;
  }
  for (int i = s->top; i >= 0; i--)
  {
    popIntegerStack(s, &(s->data[i]));
  }
  return 1;
}
int isIntegerStackEmpty(struct stack *s)
{
  if (s->top == -1 || (s->length <= 0))
  {
    return 1;
  }
  return 0;
}
int isIntegerStackFull(struct stack *s1)
{
  if ((s1->top == s1->length - 1) || (s1->length <= 0))
  {
    return 1;
  }
  return 0;
}
int main()
{
  struct stack s1;

  int c, l;
  int elem, ele, check;
  init(&s1);
  while (1)
  {
    printf("\nEnter the following choices for the desired opreations to be done\n 1. Create an Integer Stack \n 2. Push Elements into the stack \n 3. Pop elements from the integer stack \n 4. Free the stack \n 5. Check for the stack is full \n 6. Check whether the stack is empty\n Press 0 to terminate the process\n");
    scanf("%d", &c);
    if (c == 1)
    {
      printf("\nEnter the size of the stack:\n");
      scanf("%d", &l);
      s1 = createIntegerStack(l);
      if (s1.length <= 0)
      {
        printf("\nOperation is not successful\n");
      }
      else
      {
        printf("\nOperation is successful\n");
      }
      continue;
    }
    else if (c == 2)
    {
      printf("\nEnter the element to be pushed:\n");
      scanf("%d", &elem);
      check = pushIntegerStack(&s1, elem);
      if (check)
      {
        printf("\nOperation is successful\n");
      }
      else
      {
        printf("\nOperation is not successful\n");
      }
      continue;
    }
    else if (c == 3)
    {
      check = popIntegerStack(&s1, &ele);
      if (check)
      {
        printf("\nOperation is successful\n");
        printf("\nThe popped element is %d\n", ele);
      }
      else
      {
        printf("\nOperation is not successful\n");
      }
      continue;
    }
    else if (c == 4)
    {
      check = freeIntegerStack(&s1);
      if (check)
      {
        printf("\nOperation is successful\n");
      }
      else
      {
        printf("\nOperation is not successful\n");
      }
      continue;
    }
    else if (c == 5)
    {
      check = isIntegerStackFull(&s1);
      if (s1.length <= 0)
      {
        printf("Stack is not created\n");
        continue;
      }
      if (check)
      {
        printf("\nThe stack is full\n");
      }
      else
      {
        printf("\nThe stack is not full\n");
      }
      continue;
    }
    else if (c == 6)
    {
      check = isIntegerStackEmpty(&s1);
      if (s1.length <= 0)
      {
        printf("Stack is not created\n");
        continue;
      }
      if (check)
      {
        printf("\nStack is empty\n");
      }
      else
      {
        printf("\nStack is not empty\n");
      }
      continue;
    }
    else if (c == 0)
    {
      break;
    }
    else
    {
      printf("\nInvalid choice try again\n");
      continue;
    }
  }
int m;
  struct stack sA2;

  printf("\nEnter the size of the stack 2\n");
  scanf("%d", &m);
  sA2 = createIntegerStack(m);
  while (isIntegerStackFull(&sA2))
  {
    int a;
    if (isIntegerStackFull(&sA1))
    {
      if (isIntegerStackFull(&sA2))
      {
        int b;
        for (int i = 0; i < m; i++)
        {
          popIntegerStack(&sA2, &b);
          printf("\nThe popped element from stack 2 is:%d\n", b);
        }
        for (int i = 0; i < n; i++)
        {
          popIntegerStack(&sA1, &b);
          printf("\nThe popped element from stack 1 is:%d\n", b);
        }
        break;
      }
      else
      {
        printf("\nEnter the integer to be pushed into the stack 2:\n");
        scanf("%d", &a);
        pushIntegerStack(&sA2, a);
      }
    }
    else
    {
      printf("\nEnter the integer to be pushed into the stack 1:\n");
      scanf("%d", &a);
      pushIntegerStack(&sA1, a);
    }
  }
  return 0;

  return 0;
}