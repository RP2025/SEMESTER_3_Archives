#include <stdio.h>
#include <string.h>

#define MAX 100

struct student{
    char name[MAX];
    int roll;
    char telephone[MAX];
    char address[MAX];
};

struct SReg{
    int count;
    struct student SR[MAX];
}; 

struct student crtstd(){
    struct student s;
    printf("Enter the name of the student: ");
    getchar();
    fgets(s.name, MAX, stdin);
    printf("Enter the roll number of the student: ");
    scanf("%d", &s.roll);
    printf("Enter the telephone number: ");
	getchar();
    fgets(s.telephone, MAX, stdin);
    printf("Enter the address of the student (Not Manditory): ");
	//getchar();
    fgets(s.address, MAX, stdin);

    return s;
}

int add(struct SReg *sr,struct student *s){
    for(int ind = 0; ind < sr->count; ind++){
        if(s->roll == sr->SR[ind].roll)
            return 0;
    }
    sr->SR[sr->count] = *s;
    sr->count++;
    return 1;
}

void prntstd(struct student s){
    printf("\nStudent Details:\nName - %sRoll - %d\nTelephone - %sAddress - %s\n", s.name, s.roll, s.telephone, s.address);
}

struct student get(struct SReg *sr, int r){
    for(int ind = 0; ind < sr->count; ind++){
        if(sr->SR[ind].roll = r)
            return sr->SR[ind];
    }
    struct student s;
    s.roll = 0;
    return s;
}

int delete(struct SReg *sr, int r){
    int temp = 0;
    for(int ind = 0; ind < sr->count; ind++){
        if(sr->SR[ind].roll = r)
            temp = ind;
    }
    if(temp == 0)
        return 0;
    for(int i = temp; i < sr->count - 1; i++){
        sr->SR[i] = sr->SR[i+1];
    }
    sr->count--;
    return 1;
}

int modify(struct SReg *sr, int r){
    int temp = 0;
    for(int ind = 0; ind < sr->count; ind++){
        if(sr->SR[ind].roll = r)
            temp = ind;
    }
    if(temp == 0)
        return 0;
    printf("Student Found. Enter modified details: ");
    printf("Enter name: ");
    fgets(sr->SR[temp].name, MAX, stdin);
    printf("Enter roll: ");
    scanf("%d", &sr->SR[temp].roll);
    printf("Enter telephone: ");
    getchar();
    fgets(sr->SR[temp].telephone, MAX, stdin);
    printf("Enter Address(Not mandatory): ");
    fgets(sr->SR[temp].address, MAX, stdin);
    return 1;
}

void sortStudent(struct SReg *sr){
    for(int ind = 0; ind < sr->count; ind++){
        for(int i = ind + 1; i < sr->count; i++){
            if(strcmp(sr->SR[ind].name, sr->SR[i].name) < 0){
                struct student s;
                s = sr->SR[ind];
                sr->SR[ind] = sr->SR[i];
                sr->SR[i] = s;
            }
        }
    }
}

int getCount(struct SReg *sr){
    return sr->count;
}

void export(struct SReg *sr, char fname[]){
    FILE *fp;
    fp = fopen(fname, "w");
    
    for(int i = 0; i < sr->count; i++){
        fprintf(fp, "%s %d %s %s\n", sr->SR[i].name, sr->SR[i].roll, sr->SR[i].telephone, sr->SR[i].address);
    }
    fclose(fp);
}

void load(struct SReg *sr, char fname[]){
    FILE *fp;
    fp = fopen(fname, "r");
    int i = 0;
    char c;
    c = fgetc(fp);
    while(c != EOF){
        if(c == '\n')
            i++;
        c = fgetc(fp);
    }
    fclose(fp);
    fp = fopen(fname, "r");
    int j = 0;
    while(j < i){
        fscanf(fp, "%s %d %s %s", sr->SR[j].name, &sr->SR[j].roll, sr->SR[j].telephone, sr->SR[j].address);
        (sr->count)++;
        j++;
    }
    fclose(fp);
}

int main()
{
    struct SReg sr;
    sr.count = 0;
    int in = 1;
    while(in){
        printf("Welcome to student register:(Press 0 to exit)\n1. Add a student.\n2. Get student information.\n3. Delete a student.\n4. Modify a student information.\n5. Sort the student.\n6. Get count of student.\n7. Export to a text file.\n8. Load from a text file.\nInput: ");
        scanf("%d", &in);
        if(in == 1){
            struct student s;
            s = crtstd();
            if(add(&sr, &s))
                printf("Added succesfully.\n");
            else
                printf("Failed to add. \n");
        }
        else if(in == 2){
            int r;
            printf("Enter student roll no: ");
            scanf("%d", &r);
            prntstd(get(&sr, r));
        }
        else if(in == 3){
            int r;
            printf("Enter student roll no.: ");
            scanf("%d", &r);
            if(delete(&sr, r))
                printf("Successfully deleted.\n");
            else
                printf("Failed to delete.\n");
        }
        else if(in == 4){
            int r;
            printf("Enter student roll no.: ");
            scanf("%d", &r);
            if(modify(&sr, r))
                printf("Succesfully modified.\n");
            else
                printf("Failed to modify.\n");
        }
        else if(in == 5){
            sortStudent(&sr);
            printf("Sorted the students.\n");
        }
        else if(in == 6){
            printf("The number of students are: %d\n", getCount(&sr));
        }
        else if(in == 7){
            char name[MAX];
            printf("Enter the name of the file: ");
            scanf("%s", name);
            export(&sr, name);
            printf("Succesfully exported.\n");
        }
        else if(in == 8){
            char name[MAX];
            printf("Enter the name of the file: ");
            scanf("%s", name);
            load(&sr, name);
            printf("Succesfully loaded.\n");
        }
        else if(in == 0){
            printf("Goodbye.\n");
        }
        else{
            printf("Wrong input.\n");
        }
    }
    
}