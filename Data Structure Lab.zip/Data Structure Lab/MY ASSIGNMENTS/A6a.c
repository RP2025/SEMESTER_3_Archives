#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

typedef struct stack{
	int top;
	int *space;
	int size;
}stack;

int isEmpty(stack *s){
	if(s->top == -1)
		return 1;
	return 0;
}

int isFull(stack *s){
	if(s->top == (s->size - 1))
		return 1;
	return 0;
}

stack createIntegerStack(int stackSize){
	stack s;
	s.space = (int*)malloc(stackSize * sizeof(int));
	s.top = -1;
	s.size = stackSize;
	return s;
}

int pushIntegerStack(stack *s, int d){
	if(!isFull(s)){
		s->top = s->top + 1;
		s->space[s->top] = d;
		return 1;
	}
	else
		return 0;
}

int popIntegerStack(stack *s, int *dp){
	if(!isEmpty(s)){
		*dp = s->space[(s->top)--];
		return 1;
	}
	return 0;
}

void displayIntegerTop(stack *s){
	if(!isEmpty(s)){
		printf("Top: %d\n", s->space[s->top]);
	}
	else
		printf("Stack is empty.\n");
}

int freeIntegerStack(stack *s){
	if(s->space == NULL)
		return 0;
	free(s->space);
	s->space = NULL;
	s->top = -1;
	s->size = 0;
	return 1;
}

int main()
{
    char exp[50];
    printf("Enter the expression: ");
    fgets(exp, 50, stdin);

    stack st = createIntegerStack(50);
	
	for(int i = 0; i < strlen(exp) - 1; i++){
		if(exp[i] == ' ') 
			continue;

		else if(isdigit(exp[i])){
			int num = 0;

			while(isdigit(exp[i])){
				num = num * 10 + (int)(exp[i] - '0');
				i++;
			}
			i--;

			pushIntegerStack(&st, num);
		}

		else{
			int val1, val2;
			popIntegerStack(&st, &val1);
			popIntegerStack(&st, &val2);

			switch(exp[i]){
				case '+': 	pushIntegerStack(&st, val2 + val1);
							break;
				case '-':	pushIntegerStack(&st, val2 - val1);
							break;
				case '*':	pushIntegerStack(&st, val2 * val1);
							break;
				case '/':	pushIntegerStack(&st, val2/val1);
							break;
				case '^':	pushIntegerStack(&st, (int)pow(val2, val1));
							break;
			}
		}
	}

	int result;
	popIntegerStack(&st, &result);
	printf("\nThe Answer is: %d", result);
}