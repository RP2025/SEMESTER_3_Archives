#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef struct stack{
	int top;
	int *space;
	int size;
}stack;

int isEmpty(stack *s){
	if(s->top == -1)
		return 1;
	return 0;
}

int isFull(stack *s){
	if(s->top == (s->size - 1))
		return 1;
	return 0;
}

stack createIntegerStack(int stackSize){
	stack s;
	s.space = (int*)malloc(stackSize * sizeof(int));
	s.top = -1;
	s.size = stackSize;
	return s;
}

int pushIntegerStack(stack *s, int d){
	if(!isFull(s)){
		s->top = s->top + 1;
		s->space[s->top] = d;
		return 1;
	}
	else
		return 0;
}

int popIntegerStack(stack *s){
	if(!isEmpty(s))
		return s->space[(s->top)--];
}

int IntegerTop(stack *s){
	if(!isEmpty(s))
		return s->space[s->top];
}

int freeIntegerStack(stack *s){
	if(s->space == NULL)
		return 0;
	free(s->space);
	s->space = NULL;
	s->top = -1;
	s->size = 0;
	return 1;
}

int Precedence(char c){
    if(c == '+' || c == '-')
        return 1;
    else if(c == '*' || c == '/')
        return 2;
    else if(c == '^')
        return 3;
    else
        return -1;
}

int main()
{
    char exp[50];
    char ans[50];
    printf("Enter the expression: ");
    fgets(exp, 50, stdin);
    int k = 0;
    stack st = createIntegerStack(50);
    for(int i = 0; i < strlen(exp) - 1; i++){
        if(exp[i] >= 'a' && exp[i] <= 'z' || exp[i] >= 'A' && exp[i] <= 'Z'){
            ans[k++] = exp[i];
        }

        else if(exp[i] == '(')
            pushIntegerStack(&st, exp[i]);
        
        else if(exp[i] == ')'){
            while(!isEmpty(&st) && IntegerTop(&st) != '(')
                ans[k++] = popIntegerStack(&st);
            
            if(!isEmpty(&st) && IntegerTop(&st) != '(')
                return -1;
            else
                popIntegerStack(&st);
        }

        else{
            while(!isEmpty(&st) && Precedence(exp[i]) <= Precedence(IntegerTop(&st)))
                ans[k++] = popIntegerStack(&st);
            pushIntegerStack(&st, exp[i]);
        }
    }

    while(!isEmpty(&st))
        ans[k++] = popIntegerStack(&st);
    
    ans[k++] = '\0';
    printf("%s", ans);
}