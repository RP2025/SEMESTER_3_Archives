#include<stdio.h>
#include<stdlib.h>

// Data structure to store a binary tree node
typedef struct tNode{
	int data;
	struct tNode *left;
	struct tNode *right;
	struct tNode *parent;
}node;

// Function to create a new binary tree node having a given data
node* createNode(int val){
	node *temp = (node*)malloc(sizeof(node));
	temp->data = val;
	temp->left = NULL;
	temp->right = NULL;
	temp->parent = NULL;
	return temp;
}

// Function to check whether the tree is empty or not
int isEmpty(node *t){
	if(t == NULL)
		return 1;
	return 0;
}


// Itterative insertion function of binary search tree. If the node exists already, it is ignored.
node* insertNode(node *t, int val){
	node *temp = createNode(val);

	if(isEmpty(t)){
		t = temp;
		return t;
	}


    // r is used to follow the ptr till the ptr reaches null and hence we find the node where the new node is to be added.
	node *ptr = t;
	node *r;
    while(ptr != NULL){
        r = ptr;
        if(val < ptr->data)
            ptr = ptr->left;
        else if(val > ptr->data)
            ptr = ptr->right;
        else 
            return t;
    }

    // Adding new node either has left child or as right child.
    if(val < r->data){
        r->left = temp;
        temp->parent = r;
    }
    else{
        r->right = temp;
        temp->parent = r;
    }

    return t;
}


// Function to get the number of nodes in BST.
int getCount(node *t){
	if(t == NULL)
		return 0;
    
    int l = getCount(t->left);
    int r = getCount(t->right);

    return 1 + l + r;
}

// Recursive function to perform inorder traversal on a given binary tre
int Inorder(node *t){
    if(t){
        Inorder(t->left);
        printf("%d ", t->data);
        Inorder(t->right);
        return 1;
    }
    return 0;
}

// Recursive function to perform postorder traversal on a given binary tre
int Postorder(node *t){
    if(t){
        Postorder(t->left);
        Postorder(t->right);
        printf("%d ", t->data);
        return 1;
    }
    return 0;
}

// Recursive function to perform preorder traversal on a given binary tre
int Preorder(node *t){
    if(t){
        printf("%d ", t->data);
        Preorder(t->left);
        Preorder(t->right);
        return 1;
    }
    return 0;
}

int main()
{
    node *root = NULL;
    int ch;
    while (1)
    {
        printf("\n1. Check if Tree is Empty.\n2. Insert data.\n3. Total nodes in BST.\n4. Inorder Traversal\n5. Preorder Traversal\n6. PostOrder Traversal\nInput(0 to terminate): ");
        scanf("%d", &ch);
        if (ch == 1){
            if (isEmpty(root))
                printf("The tree is empty\n");
            else
                printf("The tree is not empty\n");
        }
        else if (ch == 2){
            int n;
            printf("Enter the value: ");
            scanf("%d", &n);
            root = insertNode(root, n);
            printf("Successfully excuted.\n");
        }
        else if (ch == 3){
            printf("The total number of nodes is: %d\n", getCount(root));
        }
        else if (ch == 4){
            int ch = Inorder(root);
            printf("\n");
            if (ch == 0)
                printf("Operation failed\n");
        }
        else if (ch == 5){
            int ch = Preorder(root);
            printf("\n");
            if (ch == 0)
                printf("Operation failed\n");
        }
        else if (ch == 6){
            int ch = Postorder(root);
            printf("\n");
            if (ch == 0)
                printf("Operation failed\n");
        }
        else if (ch == 0){
            printf("Goodbye\n");
            break;
        }
        else{
            printf("Wrong Choice\n");
        }
    }
    return 0;
}