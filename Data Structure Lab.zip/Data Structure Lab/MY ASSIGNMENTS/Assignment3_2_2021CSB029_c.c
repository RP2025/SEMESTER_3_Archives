#include <stdio.h>
#include <stdlib.h>
struct stack
{
  int top;
  int *data;
  int length;
};
void init(struct stack *s1)
{
  s1->top = -1;
}
struct stack createIntegerStack(int stackSize)
{
  if (stackSize <= 0)
  {
    struct stack s3;
    init(&s3);
    s3.length = 0;
    return s3;
  }
  struct stack s2;
  init(&s2);
  s2.data = (int *)malloc(stackSize * sizeof(int));
  s2.length = stackSize;
  return s2;
}
int pushIntegerStack(struct stack *s1, int d)
{
  if (s1->top == (s1->length) - 1)
  {
    return 0;
  }
  s1->data[++(s1->top)] = d;
  return 1;
}
int popIntegerStack(struct stack *s, int *dp)
{
  if (s->top == -1)
  {
    return 0;
  }
  *dp = s->data[(s->top)--];
  return 1;
}
int isIntegerStackEmpty(struct stack *s)
{
  if (s->top == -1)
  {
    return 1;
  }
  return 0;
}
int isIntegerStackFull(struct stack *s1)
{
  if (s1->top == s1->length - 1)
  {
    return 1;
  }
  return 0;
}
int main()
{
  int n, m;
  struct stack sA1, sA2;
  printf("\nEnter the size of the stack 1:\n");
  scanf("%d", &n);
  sA1 = createIntegerStack(n);
  printf("\nEnter the size of the stack 2\n");
  scanf("%d", &m);
  sA2 = createIntegerStack(m);
  while (1)
  {
    int a;
    if (isIntegerStackFull(&sA1))
    {
      if (isIntegerStackFull(&sA2))
      {
        int b;
        for (int i = 0; i < m; i++)
        {
          popIntegerStack(&sA2, &b);
          printf("\nThe popped element from stack 2 is:%d\n", b);
        }
        for (int i = 0; i < n; i++)
        {
          popIntegerStack(&sA1, &b);
          printf("\nThe popped element from stack 1 is:%d\n", b);
        }
        break;
      }
      else
      {
        printf("\nEnter the integer to be pushed into the stack 2:\n");
        scanf("%d", &a);
        pushIntegerStack(&sA2, a);
      }
    }
    else
    {
      printf("\nEnter the integer to be pushed into the stack 1:\n");
      scanf("%d", &a);
      pushIntegerStack(&sA1, a);
    }
  }
  return 0;
}
