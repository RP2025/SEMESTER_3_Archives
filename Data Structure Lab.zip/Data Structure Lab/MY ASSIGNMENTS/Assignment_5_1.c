#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct student{
    char name[20];
    unsigned int roll;
    unsigned int marks;
    struct student *next;
} student;

student *createLl(char name[],unsigned int roll,
                    unsigned int marks){
    student *s1 = malloc(sizeof(student));
    strcpy(s1->name,name);
    s1->roll = roll;
    s1->marks = marks;
    s1->next = NULL;
    return s1;
}

student* addSNodeSorted(student *head, char name[],
                        unsigned int roll, unsigned int marks){
    student *stu = createLl(name, roll, marks);
    if(head == NULL){
        return stu;
    }
    else if (head->marks <= marks){
        stu->next = head;
        return stu;
    }
    else{
        student* ptr = head;
        while(ptr->marks >= marks){
            if(ptr->next == NULL){
                ptr->next = stu;
                return head;
            }
            else if(ptr->next->marks >= marks){
                ptr = ptr->next;
            }
            else{
                stu->next = ptr->next;
                ptr->next = stu;
                return head;
            }
        }
    }
}

int isPresentSNodeSorted(student* head,unsigned int roll){
    int c = 1;
    student* temp = head;
    while(temp != NULL){
        if(temp->roll == roll){
            return c;
        }
        temp = temp->next;
        c++;
    }
    return 0;
}

student *deleteSNodeSorted(student *head,unsigned int roll){
    student *temp = head->next;
    if (head->roll == roll) {
        free(head);
        return temp;
    }
    else if (temp->roll == roll){
        head->next = temp->next;
        free(temp);
        return head;
    }
    else{
        while(temp->next != NULL) {
            if (temp->next->roll == roll) {
                student *ptr = temp->next;
                temp->next = ptr->next;
                free(ptr);
                return head;
            }
            temp = temp->next;
        }
    }
    return 0;
}

void printLl(student *head){
    student *temp = head;
    while(temp != NULL){
        printf("Name    : %s\n", temp->name);
        printf("Roll    : %d\n", temp->roll);
        printf("Marks   : %d\n", temp->marks);
        printf("-----------------------\n");
        temp = temp->next;
    }
}

void freeLl(student *head){
    student * temp = head;
    student * del;
    while(temp!=NULL){
        del = temp;
        temp = temp->next;
        free(del);
    }
}

int main(){
    int a = 1,c;
    student *head = NULL;
    while(a){
        char name[20]; unsigned int roll, marks, q;
        printf("Enter    1 for display \n\t 2 for insertion \n\t 3 for searching \n\t 4 for deletion \n\t 5 for free and quit \n");
        scanf("%d",&q);
        if(q == 2){
            printf("Enter name, roll, marks : \n");
            scanf("%s%d%ud",name,&roll,&marks);
        }
        else if(q == 3 || q == 4){
            printf("Enter roll : \n");
            scanf("%d",&roll);
        }
        switch(q){
            case 1:
                printLl(head);
                break;
            case 2:
                head = addSNodeSorted(head,name,roll,marks);
                break;
            case 3:
                c = isPresentSNodeSorted(head,roll);
                (c == 0)?printf("Node is absent\n")
                        :printf("Node is at %d index\n",c-1);
                break;
            case 4:
                head = deleteSNodeSorted(head,roll);
                break;
            case 5:
                freeLl(head);
                a = 0;
                break;
        }
    }
    return 0;
}
