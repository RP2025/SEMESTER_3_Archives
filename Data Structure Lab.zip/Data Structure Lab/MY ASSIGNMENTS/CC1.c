#include <stdio.h>
#include <stdlib.h>

//structure to create nodes of linked list
typedef struct Node
{
    int coeff;
    int exp;
    struct Node *next;
} Node;


//function to create linked list representation of polynomial
Node *addToList(Node *head, int coeff, int exp)
{

    Node *temp;
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->coeff = coeff;
    newNode->exp = exp;

    if (head == NULL)
    {
        head = newNode;
        newNode->next = head;
    }
    else
    {
        if (exp > (head->exp))
        {
            temp = head;
            while (temp->next != head)
            {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
            head = newNode;
        }
        else
        {
            temp = head;
            while (temp->next != head && (temp->next->exp) > exp)
            {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }
    return head;
}


//function to accept user input to make polynomials
Node *makePoly(Node *head)
{
    int n;
    int i;
    int coeff, exp;

    printf("\n\nEnter the number of terms : ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        printf("\nEnter the coefficient for term %d: ", i);
        scanf("%d", &coeff);

        printf("Enter the exponent for term %d: ", i);
        scanf("%d", &exp);

        head = addToList(head, coeff, exp);
    }
    return head;
}


//function to print polynomial
void printList(Node *head)
{
    if (head == NULL)
    {
        printf("Empty polynomial!!");
        return;
    }

    Node *temp = head;
    do
    {
        if (temp->coeff != 0)
        {
            if (temp->exp == 0)
            {
                printf("%d", temp->coeff); // printing only constant when power = 0
            }
            else if (temp->exp == 1)
            {
                printf("%dx", temp->coeff); // printing only x when power = 1
            }
            else
            {
                printf("%dx^%d", temp->coeff, temp->exp); // printing when x != 0 or 1
            }
        }

        temp = temp->next;
        if (temp != head && temp->coeff != 0)
            printf(" + ");

    } while (temp != head);
}


//function to add two polynomials
Node *addPoly(Node *poly1, Node *poly2, Node *poly)
{

    Node *temp = poly;   // stores head of the sum
    Node *temp1 = poly1; // stores head of 1st polynomial
    Node *temp2 = poly2; // stores head of 2nd polynomial
    int flag1 = 0, flag2 = 0;

    do
    {
        if (poly1->exp > poly2->exp)
        {
            poly->coeff = poly1->coeff;
            poly->exp = poly1->exp;
            poly1 = poly1->next;
            flag1 = 1;
        }
        else if (poly2->exp > poly1->exp)
        {
            poly->coeff = poly2->coeff;
            poly->exp = poly2->exp;
            poly2 = poly2->next;
            flag2 = 1;
        }
        else if (poly1->exp == poly2->exp)
        {
            poly->coeff = poly1->coeff + poly2->coeff;
            poly->exp = poly1->exp;
            poly1 = poly1->next;
            poly2 = poly2->next;
            flag1 = flag2 = 1;
        }

        poly->next = (Node *)malloc(sizeof(Node));
        poly = poly->next;
        poly->coeff = 0;
        poly->exp = 0;
        poly->next = temp;

        if ((poly1 == temp1 || poly2 == temp2) && ((flag1 == 1) && (flag2 == 1)))
            break;

        if ((poly2 == temp2 && flag2 == 1) && (flag1 == 0))
            break;

        if ((poly1 == temp1 && flag1 == 1) && (flag2 == 0))
            break;

    } while (1);

    do
    {
        if (poly1 == temp1 && flag1 == 1)
            break;

        poly->coeff = poly1->coeff;
        poly->exp = poly1->exp;
        poly1 = poly1->next;
        flag1 = 1;

        poly->next = (Node *)malloc(sizeof(Node));
        poly = poly->next;
        poly->coeff = 0;
        poly->exp = 0;
        poly->next = temp;

        
    } while (1);

    do
    {
        if (poly2 == temp2 && flag2 == 1)
            break;

        poly->coeff = poly2->coeff;
        poly->exp = poly2->exp;
        poly2 = poly2->next;
        flag2 = 1;

        poly->next = (Node *)malloc(sizeof(Node));
        poly = poly->next;
        poly->coeff = 0;
        poly->exp = 0;
        poly->next = temp;

    } while (1);

    return temp;
}


//function to free the polynomials
void freeList(Node *head)
{
    Node *temp;
    Node *start = head;

    do
    {
        temp = head;
        head = head->next;
        free(temp);
    } while (head != start);
}


//main function
int main()
{

    // For polynomial 1
    printf("\nFor Polynomial 1 : -");
    Node *head1 = NULL;
    head1 = makePoly(head1);
    printf("\n");

    // For polynomial 2
    printf("\nFor Polynomial 2 : -");
    Node *head2 = NULL;
    head2 = makePoly(head2);
    printf("\n");


    // printing the two polynomials
    printf("\nThe two polynomials are as follows:");
    printf("\n");
    printList(head1);
    printf("\n");
    printList(head2);

    // For sum or resultant polynomial
    printf("\n\nThe sum/resultant polynomial is as follows : -");
    Node *head = NULL;
    head = addToList(head, 0, 0);
    printf("\n");
    head = addPoly(head1, head2, head);
    printList(head);

    // freeing the polynomials
    freeList(head1);
    freeList(head2);
    freeList(head);
    printf("\n\nAll polynomials freed.");
}