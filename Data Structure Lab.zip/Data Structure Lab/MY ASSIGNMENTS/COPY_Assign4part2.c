#include <stdio.h>
#include <stdlib.h>

typedef struct Queue{
    int front;
    int rear;
    int *space;
    unsigned short count;
    unsigned int size;
}Queue;

Queue* createIntegerQueue(int qSize){
	Queue *qe = (Queue*)malloc(sizeof(Queue));
	qe->space = (int*)malloc(qSize * sizeof(Queue));
	qe->front = 0;
	qe->rear = 0;
    qe->count = 0;
	qe->size = qSize;
	if(qe->space == NULL)
		return NULL;
	else
		return qe;
}

int freeIntegerQueue(Queue *q){
	if(q == NULL)
		return 0;
	free(q->space);
	free(q);
	return 1;
}

int isIntegerQueueFull(Queue *q){
    if(q->count == q->size){
        return 1;
    }
    return 0;
}

int isIntegerQueueEmpty(Queue *q){
    if(q->count == 0)
        return 1;
    return 0;
}

int enqueueInteger(Queue *q, int d){
    if(!isIntegerQueueFull(q)){
        if(q->rear != q->size - 1){
            q->space[q->rear] = d;
            q->rear++;
            q->count++;
        }
        else{
            q->space[q->rear] = d;
            q->rear = 0;
            q->count++;
        }
        return 1;
    }
    return 0;
}

int dequeueInteger(Queue *q, int *dp){
    if(!isIntegerQueueEmpty(q)){
        if(q->front != q->size - 1){
            *dp = q->space[q->front];
            q->space[q->front] = 0;
            q->front++;
            q->count--;
        }
        else{
            *dp = q->space[q->front];
            q->space[q->front] = 0;
            q->front = 0;
            q->count--;
        }
        return 1;
    }
    return 0;
}

int showFirstInteger(Queue *q){
	if(!isIntegerQueueEmpty(q)){
		return q->space[q->front];
	}
	else 
		return 0;
}

int display(Queue *q) {
    printf("Count: %d\n",q->count);
    printf("Front: %d\n",q->front);
    printf("Rear: %d\n",q->rear);
	for (int i = 0; i < q->size; i++ ){
		printf("%2d ",q->space[i]);
	}
	printf("\n");
}

int main()
{
    Queue *q;
    int size;
    printf("Enter size of the queue: ");
    scanf("%d", &size);
	q = createIntegerQueue(size);
    while(!isIntegerQueueFull(q)){
        printf("Enter element: ");
        int elem;
        scanf("%d", &elem);
        if(enqueueInteger(q, elem))
            continue;
        else
            printf("Queue is full.\n");
    }
    while(!isIntegerQueueEmpty(q)){
        int qelem;
        if(!dequeueInteger(q, &qelem))
            printf("Queue is empty.\n");
        else{
            if(qelem > 0){
                int rVal = rand() % 9 + 1;
                qelem = qelem - rVal;
                enqueueInteger(q, qelem);
                display(q);
            }
            /*else
                continue;*/
        }
    }
}