#include <stdio.h>
#include <stdlib.h>

struct Node {
    int coeff;
    int power;
    struct Node* next;
};

void create_node(int cof , int powx , struct Node** temp){
    struct Node *r;
    struct Node *z = *temp;
    r = (struct Node*)malloc(sizeof(struct Node));
    r->coeff = cof;
    r->power = powx;

    if(z == NULL)
    {
        *temp = r;
        (*temp)->next = *temp;
    }

    else{
        r -> next = z -> next;
        z -> next = r;
        *temp = r;
    }

}

void add_poly(struct Node* pol1 , struct Node* pol2 , struct Node** temp){
    struct Node *start1 = pol1;
    struct Node *start2 = pol2;

    pol1 = pol1 -> next;
    pol2 = pol2 -> next; 

    //Traversing Both Circular LL
    while ( pol1 != start1 && pol2 != start2)
    {
        struct Node* r;
        struct Node* z = *temp;
        r = (struct Node*)malloc(sizeof(struct Node));
        r -> coeff = 0;
        if (pol1 -> power > pol2 -> power){
            r -> coeff = pol1 -> coeff;
            r -> power = pol1 -> power;
            pol1 = pol1 -> next;
        }
        
        else if (pol1 -> power < pol2 -> power){
            r -> coeff = pol2 -> coeff;
            r -> power = pol2 -> power;
            pol2 = pol2 -> next;
        }

        else {
            r -> coeff = pol1 -> coeff + pol2 -> coeff;
            r -> power = pol1 -> power;
            pol1 = pol1 -> next;
            pol2 = pol2 -> next;
        }

        if (z == NULL){
            *temp = r;
            (*temp) -> next = *temp;
        }

        else{
            r -> next = z -> next;
            z -> next = r;
            *temp = r;
        }
    }

    while(pol1 != start1 || pol2 != start2){
        if( pol1 != start1){
            struct Node* r;
            struct Node* z = *temp;
            r = (struct Node*)malloc(sizeof(struct Node));

            r -> coeff = pol1 -> coeff;
            r -> power = pol1 -> power;
            
        
            if (z == NULL){
            *temp = r;
            (*temp) -> next = *temp;
            }

            else{
            r -> next = z -> next;
            z -> next = r;
            *temp = r;
            }
            pol1 = pol1 -> next;
        }

        if( pol2 != start1){
            struct Node* r;
            struct Node* z = *temp;
            r = (struct Node*)malloc(sizeof(struct Node));

            r -> coeff = pol2 -> coeff;
            r -> power = pol2 -> power;
            
        
            if (z == NULL){
            *temp = r;
            (*temp) -> next = *temp;
            }

            else{
            r -> next = z -> next;
            z -> next = r;
            *temp = r;
            }
             pol2 = pol2 -> next;
        }
       
    }

    struct Node *r;
    struct Node *z = *temp;
    r = (struct Node*)malloc(sizeof(struct Node));
    
    //r -> coeff = 0;
    if (start1 -> power > start2 -> power)
    {
        r -> coeff = start1 -> coeff;
        r -> power = start1 -> power;   
    }

    else if (start1 -> power < start2 -> power)
    {
        r -> coeff = start2 -> coeff;
        r -> power = start2 -> power;   
    }

    else {
        r -> coeff = start1 -> coeff + start2 -> coeff;
        r -> power = start1 -> power;
    } 

    if (z == NULL){
        *temp = r;
        (*temp) -> next = *temp;
    }

    else{
        r -> next = z -> next;
        z -> next = r;
        (*temp) = r;
    } 

}

//DISPLAY

void display(struct Node* dis){
    struct Node* start = dis;
    dis= dis -> next;
    while( dis != start && dis -> coeff != 0){
        printf("%d x^ %d" , dis -> coeff , dis -> power);
        if (dis != start && dis -> next -> next -> coeff != 0) 
        {
            printf(" + ");
        }

        dis = dis -> next;
    }
/*
    printf("%d" , dis -> coeff);
    if (dis -> power != 0)
    {
        printf("x^%d" , dis -> power);
    }
    */
}

int main()
{
    struct Node *poly1 = NULL;
    struct Node *poly2 = NULL;
    struct Node *pol_add = NULL;

    int n1,n2;
    printf("Enter the number of expression in polymonial 1 ::");
    scanf("%d" , &n1);
    for(int i = 0 ; i < n1 ; i++)
    {   int cof_temp , power_temp;
        printf("Enter coefficient and power ::");
        scanf("%d%d" , &cof_temp , &power_temp);
        create_node(cof_temp , power_temp , &poly1);
    }

    printf("Enter the number of expression in polymonial 2 ::");
    scanf("%d" , &n2);
    for(int i = 0 ; i < n2 ; i++)
    {   int cof_temp , power_temp;
        printf("Enter coefficient and power ::");
        scanf("%d%d" , &cof_temp , &power_temp);
        create_node(cof_temp , power_temp , &poly2);
    }

    add_poly(poly1, poly2 , &pol_add);
    printf("First Polynomial is :: ");
    display(poly1);
    printf("Second Polynomial is :: ");
    display(poly2);
    printf("First Polynomial is :: ");
    display(pol_add);

    return 0;
}