 /* error: invalid operands to binary & (have 'char *' and 'unsigned int')
   65 |         scanf("%d%d" &roll , &marks);
      |               ~~~~~~ ^
      |               |
      |               char **/


#include <stdio.h>
#include <stdlib.h>

typedef struct student 
{
    char name[20];         /* stores the name of the student */
    int roll;     /* stores the roll number of the student */
    int marks;    /* stores the marks of the student */
    struct student *next;  /* points to the next node in the liked-list */
}student;

student *s1;
void adding_node(struct student *head)
{
    char name[20];
    int roll;
    int marks;
    printf("Enter details");
    scanf("%s" , name);
    scanf("%d%d", &roll , &marks);
    if(head == NULL)
    {
        head = (struct student*)malloc(sizeof(struct student));
        head -> name[20] = name[20];
        head -> roll = roll;
        head -> marks = marks;
        head -> next = NULL;
    
    }

    // adding node to the last
    // TASK 1 :: Sort the list
    // TASK 2 :: Add node directly at the sprted position

    else
    {
        while (head -> next != NULL)
        {
            head = head -> next;
        
        head -> next = (struct student*)malloc(sizeof(struct student));
        head -> next -> roll = roll;
        head -> next -> marks = marks;
        head -> next -> next = NULL;
        }
    }
}

void display(struct student *s)
{
    while(s!=NULL)
    {
        printf("roll----%d \n Marks---%d" , s->roll , s->marks);
        s = s->next;
    }
}

void main()
{
    
    int ch;
    do{
        scanf("%d" , &ch);
        switch(ch)
        {
            case 1: adding_node(s1);
            break;
            case 2: display(s1);
            printf("PRINTING.....");
            break;
            case 0: printf("END"); break;
        }

    }
    while(ch != 0);

    
}

