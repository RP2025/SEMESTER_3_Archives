 /* error: invalid operands to binary & (have 'char *' and 'unsigned int')
   65 |         scanf("%d%d" &roll , &marks);
      |               ~~~~~~ ^
      |               |
      |               char **/


#include <stdio.h>
#include <stdlib.h>

typedef struct student 
{
    char name[20];         /* stores the name of the student */
    int roll;     /* stores the roll number of the student */
    int marks;    /* stores the marks of the student */
    struct student *next;  /* points to the next node in the liked-list */
}student;

student *head = NULL;
student *tail = NULL;
void adding_node()
{
    char name[20];
    int roll;
    int marks;
    printf("Enter details");
    scanf("%s" , name);
    scanf("%d%d", &roll , &marks);
    
    struct student *newNode = (struct student*)malloc(sizeof(struct student));

    newNode -> name[20] = name[20];
    newNode -> roll = roll;
    newNode -> marks = marks;
    newNode -> next = NULL;

    if(head == NULL)
    {
        head = newNode;
        tail = newNode;
    
    }

    // adding node to the last
     else
     {
        tail -> next = newNode;
        tail = newNode;
     }


    // TASK 1 :: Sort the list
    // TASK 2 :: Add node directly at the sprted position

}

void display()
{   
    struct student *current = head;
    if(head == NULL)
    {
        printf("MTY");
        return;
    }

    while(current != NULL)
    {
        printf("%d" , current->roll);
        current = current->next;
    }

}

void main()
{
    struct student s1;
    int ch;
    do{
        scanf("%d" , &ch);
        switch(ch)
        {
            case 1: adding_node();
            break;
            case 2: display();
            printf("PRINTING.....");
            break;
            case 0: printf("END"); break;
        }

    }
    while(ch != 0);

    
}

