#include <stdio.h>
#include <stdlib.h>
int count = 0;
int count2 = 0;
struct queue
{
    int size;
    int front;
    int rear;
    int *arr;
};

void init(struct queue *q1)
{
  q1->size = 0;
  q1->front = -1;
  q1->rear = -1;
}

struct queue createIntegerQueue(int queueSize)
{
    if (queueSize <= 0)
    {
    struct queue q3;
    init(&q3);
    q3.size = queueSize;
    return q3;
    }
    
    struct queue q2;
    init(&q2);
    q2.arr = (int *)malloc(queueSize * sizeof(int));
    q2.size = queueSize;
    return q2;
}

int isIntegerQueueFull(struct queue *q)
{
    //if(q->rear == q->size-1)
   // {
     //   return 1;
   // }
    if(count == count2)
    {
        return 1;
    }
    return 0;
}

int isIntegerQueueEmpty(struct queue *q)
{
    if(count == 0){
        return 1;
    }
    return 0;
//    if (q->front == q->rear)
//    {
//        return 1;
//    }
//    return 0;
}

int enqueueInteger(struct queue *q, int d)
{
    if (count == count2)
    {
        return 0;
    }
    q->rear++;
    q->arr[q->rear] = d;
    return 1;
    count++;
}

int dequeueInteger(struct queue *q, int *dp)
{
    if (q->front == q->rear)
    {
        return 0;
    }
    q->front++;
    *dp = q->arr[q->front];
    return 1;
    count--;

}

int freeIntegerQueue(struct queue *q)
{
  if ( q->front == q->rear )
  {
    return 0;
  }
  while (q->front == q->rear)
  {
    q->front++;
  }
  return 1;
}
int main()
{   
    int N;
    int qElement; // this element will be dequeued
    printf("Enter the size of queue your want to create:\n");
    scanf("%d" , &N);
    count = N;
    count2 = N;
    struct queue myQueue;
    myQueue = createIntegerQueue(N);
    enqueueInteger(&myQueue , 0);
    printf("Enter positive elements to be filled in Queue\n");
    for(int i = 0;i<N;i++)
    {   
        int element;
        scanf("%d\n" , &element);
        enqueueInteger(&myQueue , element);
    }
    while(isIntegerQueueEmpty(&myQueue) == 0)
    {   // Queue is full so it will do dequeue and enqueue
        dequeueInteger(&myQueue , &qElement);
        printf("Dequeued Element is %d \n" , qElement);
        int rValue = rand() % 9 + 1;
        qElement = qElement - rValue;
        printf("New qElement is %d \n" , qElement);
        if(qElement > 0)
        {   
            printf("Enqueued Element is %d \n" , qElement);
            enqueueInteger(&myQueue ,qElement);
        }

        if(qElement< 0)
        {   
            printf("it wont be queued");
        }


        if(isIntegerQueueFull(&myQueue))
        {
            break;
        }
    
        // Filling Queue until its full
        

    }
    return 0;
}
