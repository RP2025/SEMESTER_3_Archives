// C program for insertion sort
#include <math.h>
#include <stdio.h>

/* Function to Swap two variables */
void swap(int a , int b)
{
    int temp = a;
    a = b;
    b = temp;
}

/* Function to sort an array using insertion sort*/
void insertion_sort(int array[], int n){
    int no_exh = 0;
    for ( int k = 1; k < n; k++ ) {
        for ( int j = k; j > 0; j-- ) {
            if ( array[j - 1] > array[j] ) {
                swap( array[j - 1], array[j] );
                no_exh++;
            } 

            else {
                break;
            }
        } // end of inner loop
    } // end of outer for
}

/* Function to print Array*/
void printArray(int arr[], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
        printf("\n");
    }
}


int main()
{   printf("Enter the size of an array");
	int n;
    scanf("%d",&n);
    int arr[n];
    printf("Enter the elements of Array");
    for(int i = 0;i<n;i++)
    {
        scanf("%d", &arr[i]);
    }
    printf("Enter the number for which the operation you want to perform");
    printf("1 : Insertion Sort -- Using Default Algorithnm");
    printf("2 : Insertion Sort -- Without Using Default Algorithnm");
    int ch;
    scanf("%d" , &ch);
    if(ch)
    {
        if(ch == 1){

            insertion_sort(arr,n);
            printArray(arr,n);
        }
    }
	return 0;
}
